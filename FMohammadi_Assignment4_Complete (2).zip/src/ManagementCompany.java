/*
 * Class: CMSC203-46519
 * Instructor: Professor Eivazi
 * Assignment #4
 * Description: This application will receive data about the property including the name of property
 * tax ID, the plots for x, y, width, and depth, and have the required constructors and methods to operate on these data
 * and return the results.
 * Due: 07/21/2022
 * Platform/compiler: Eclipse
 * I pledge that I have completed the programming assignment independently.
   I have not copied the code from a student or any source.
   I have not given my code to any student.
   Print your Name here: Fakhreya Mohammadi
*/

// The class ManagementCompany is created
public class ManagementCompany {

	// the fields are declared or declared and initialized
	private final int MAX_PROPERTY = 5;
	private double mgmFeePer;
	private String name;
	private Property[] properties;
	private String taxID;
	private final int MGMT_WIDTH = 10;
	private final int MGMT_DEPTH = 10;
	private Plot plot;

	// No-Arg Constructor that creates a ManagementCompany object using empty
	// strings and a default Plot.
	// "properties" array is initialized here as well.
	public ManagementCompany() {
		mgmFeePer = 0;
		name = "";
		taxID = "";
		plot = new Plot(0, 0, MGMT_WIDTH, MGMT_DEPTH);
		properties = new Property[MAX_PROPERTY];
	}

	/**
	 * Constructor Creates a ManagementCompany object using the passed information.
	 * Mgmt Co plot is initialized to default Plot. "properties" array is
	 * initialized here as well.
	 * 
	 * @param name   The name of the company
	 * @param taxID  The tax ID of the company
	 * @param mgmFee The management fee of the company
	 */
	public ManagementCompany(String name, String taxID, double mgmFee) {
		this.name = name;
		this.taxID = taxID;
		this.mgmFeePer = mgmFee;
		plot = new Plot(0, 0, MGMT_WIDTH, MGMT_DEPTH);
		properties = new Property[MAX_PROPERTY];
	}

	/**
	 * Constructor Creates a ManagementCompany object using the passed information.
	 * "properties" array is initialized here as well.
	 * 
	 * @param name   The name of the company
	 * @param taxID  The tax ID of the company
	 * @param mgmFee The management fee for the company
	 * @param x      The x of the plot
	 * @param y      The y of the plot
	 * @param width  The width of the plot
	 * @param depth  The depth of the plot
	 */
	public ManagementCompany(String name, String taxID, double mgmFee, int x, int y, int width, int depth) {
		this.name = name;
		this.taxID = taxID;
		this.mgmFeePer = mgmFee;
		plot = new Plot(x, y, width, depth);
		properties = new Property[MAX_PROPERTY];
	}

	/**
	 * Copy Constructor creates a ManagementCompany object using another
	 * ManagementCompany object. "properties" array is initialized here as well.
	 * 
	 * @param otherCompany The other company to copy from
	 */
	public ManagementCompany(ManagementCompany otherCompany) {
		this.name = otherCompany.name;
		this.taxID = otherCompany.taxID;
		this.mgmFeePer = otherCompany.mgmFeePer;
		this.plot = otherCompany.plot;
		this.properties = otherCompany.properties;
	}

	/**
	 * Adds the property object to the "properties" array.
	 * 
	 * @param property Copy a property and add it to the array
	 * @return addProperty methods will return the index of the array where the
	 *         property is added. If there is a problem adding the property, this
	 *         method will return -1 if the array is full, -2 if the property is
	 *         null, -3 if the plot for the property is not encompassed by the
	 *         management company plot, or -4 if the plot for the property overlaps
	 *         any other property’s plot.
	 */
	public int addProperty(Property property) {

		Property Property;

		// Using the try if the property is null, it will return -2
		try {
			Property = new Property(property.getPropertyName(), property.getCity(), property.getRentAmount(),
					property.getOwner(), property.getPlot().getX(), property.getPlot().getY(),
					property.getPlot().getWidth(), property.getPlot().getDepth());
		} catch (Exception e) {
			return -2;
		}

		int count = 0;

		// iterate through each property. and if the property at the index isn't null,
		// add 1
		// to count. If the property overlaps
		// Something else in the array, return -4
		for (Property p : properties)
			if (p != null) {
				count++;
				if (p.getPlot().overlaps(Property.getPlot())) {
					return -4;
				}
			}

		// it will return -1 if the array is full
		if (count > MAX_PROPERTY - 1) {
			return -1;
		}

		// If the property is inside the company plot, put the property in the array and
		// return the index
		if (plot.encompasses(Property.getPlot())) {
			properties[count] = Property;

			Property = null;
			return count;
		}

		// it will return -3 if the plot is not is not encompassed by the management
		// company plot
		return -3;
	}

	/**
	 * Creates a property object and adds it to the "properties" array, in a default
	 * plot.
	 * 
	 * @param name  The name of the property
	 * @param city  The city of the property
	 * @param rent  The rent of the property
	 * @param owner The owner of the property
	 * @return addProperty methods will return the index of the array where the
	 *         property is added. If there is a problem adding the property, this
	 *         method will return -1 if the array is full, -2 if the property is
	 *         null, -3 if the plot for the property is not encompassed by the
	 *         management company plot, or -4 if the plot for the property overlaps
	 *         any other property’s plot.
	 */

	public int addProperty(String name, String city, double rent, String owner) {
		Property Property;

		// Using the try if the property is null, it will return -2
		try {
			Property = new Property(name, city, rent, owner);
		} catch (Exception e) {
			return -2;
		}

		int count = 0;

		// iterate through each property. and if the property at the index isn't null,
		// add 1
		// to count. If the property overlaps
		// Something else in the array, return -4
		for (Property p : properties)
			if (p != null) {
				count++;
				if (p.getPlot().overlaps(Property.getPlot())) {
					return -4;
				}
			}

		// it will return -1 if the array is full
		if (count > MAX_PROPERTY - 1)
			return -1;

		// If the property is inside the company plot, put the property in the array and
		// return the index
		if (plot.encompasses(Property.getPlot())) {

			properties[count] = Property;

			Property = null;
			return count;
		}

		// it will return -3 if the plot is not is not encompassed by the management
		// company plot
		return -3;
	}

	/**
	 * Creates a property object and adds it to the "properties" array.
	 * 
	 * @param name  The name of the property
	 * @param city  The city of the property
	 * @param rent  The rent of the property
	 * @param owner The owner of the property
	 * @param x     The x of the plot
	 * @param y     The y of the plot
	 * @param width The width of the plot
	 * @param depth The depth of the plot
	 * @return addProperty methods will return the index of the array where the
	 *         property is added. If there is a problem adding the property, this
	 *         method will return -1 if the array is full, -2 if the property is
	 *         null, -3 if the plot for the property is not encompassed by the
	 *         management company plot, or -4 if the plot for the property overlaps
	 *         any other property’s plot.
	 */
	public int addProperty(String name, String city, double rent, String owner, int x, int y, int width, int depth) {
		Property Property;

		// Using the try if the property is null, it will return -2
		try {
			Property = new Property(name, city, rent, owner, x, y, width, depth);
		} catch (Exception e) {
			return -2;
		}

		int count = 0;

		// iterate through each property. and if the property at the index isn't null,
		// add 1
		// to count. If the property overlaps
		// Something else in the array, return -4
		for (Property p : properties)
			if (p != null) {
				count++;
				if (p.getPlot().overlaps(Property.getPlot())) {
					return -4;
				}
			}

		// it will return -1 if the array is full
		if (count > MAX_PROPERTY - 1)
			return -1;

		// If the property is inside the company plot, put the property in the array and
		// return the index
		if (plot.encompasses(Property.getPlot())) {

			properties[count] = Property;

			Property = null;
			return count;
		}

		// it will return -3 if the plot is not is not encompassed by the management
		// company plot
		return -3;
	}

	/**
	 * Displays the information of the property at index i
	 * 
	 * @param i What index to get the property at
	 * @return The property information at index i
	 */
	public String displayPropertyAtIndex(int i) {
		return properties[i].toString();
	}

	/**
	 * Return the MAX_PROPERTY constant that represent the size of the "properties"
	 * array. It gets the max property limit
	 * 
	 * @return the value of MAX_PROPERTY
	 */
	public int getMAX_PROPERTY() {
		return MAX_PROPERTY;
	}

	/**
	 * It gets the index of property with the max rent and returns the maximum rent
	 * as double
	 * 
	 * @return The the maximum rent of properties
	 */
	public double maxRentProp() {
		double maximum = properties[maxRentPropertyIndex()].getRentAmount();
		return maximum;
	}

	/**
	 * Gets the index with the max rent amount
	 * 
	 * @return It returns the index at which there is the max rent of all properties
	 */

	// This method finds the property with the maximum rent amount and returns its
	// toString result.
	public int maxRentPropertyIndex() {
		// Variables to hold the
		double largest = 0;
		int maximumIndex = 0;
		int count = 0;

		// it loops through each of the properties and finds the index of the
		// property that highest rent
		// at the end it will return the index of property that has highest rent
		for (Property p : properties) {
			if (p != null) {
				if (p.getRentAmount() > largest) {
					largest = p.getRentAmount();
					maximumIndex = count;
				}

				count++;
			}
		}

		// Return the max index
		return maximumIndex;
	}

	/**
	 * Gets the whole properties array attributes
	 * 
	 * @return It returns the attributes of all properties as string representation
	 * 
	 */
	public String toString() {

		String listOfProperties = "";
		for (int n = 0; n < MAX_PROPERTY; n++) {
			if (properties[n] == null) {
				break;
			}
			listOfProperties += properties[n] + "\n";
		}
		return "List of the properties for " + name + ", taxID: " + taxID
				+ "\n__________________________________________________\n" + listOfProperties
				+ "__________________________________________________\n" + "total management Fee: "
				+ (totalRent() * mgmFeePer / 100);
	}

	/**
	 * This method accesses each "Property" object within the array "properties" and
	 * sums up the property rent and returns the total amount. It iterates through
	 * all properties of management company and adds to get the sum of them
	 * 
	 * @return It returns the sum of all property rent
	 */
	public double totalRent() {
		double total = 0;
		for (Property p : properties)
			if (p != null)
				total += p.getRentAmount();
		return total;
	}

	/**
	 * It gets the plot the Management company is set to
	 * 
	 * @return The reference to the company's plot that was set
	 */
	public Plot getPlot() {
		return plot;
	}

	/**
	 * It sets the company plot
	 * 
	 * @param plot sets the company's plot
	 */
	public void setPlot(Plot plot) {
		this.plot = plot;
	}

	/**
	 * Gets the name of the company
	 * 
	 * @return The value of name
	 */
	public String getName() {
		return name;
	}

	/**
	 * Sets the name to what was passed
	 * 
	 * @param name sets the name
	 */
	public void setName(String name) {
		this.name = name;
	}
}