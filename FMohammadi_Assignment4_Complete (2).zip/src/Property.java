/**
 * Program: Class Property; Represents a Property object
 * @author Fakhreya Mohammadi - 7/21/2022
 * holds the fields of city, owner, propertyName, rentAmount, and plot
 */


// Class Property starts here
public class Property {

	// the fields are declared
	private String city;
	private String owner;
	private String propertyName;
	private double rentAmount;
	private Plot plot;

	// No-arg Constructor, creates a new object with default values of empty
	// strings, 0 for rent amount, and default Plot
	public Property() {
		this.city = "";
		this.owner = "";
		this.propertyName = "";
		this.rentAmount = 0;
		this.plot = new Plot();
	}

	// Copy Constructor, creates a new object using the information of the object
	// passed to it.
	public Property(Property p) {
		this.city = p.city;
		this.owner = p.owner;
		this.propertyName = p.propertyName;
		this.rentAmount = p.rentAmount;
		this.plot = new Plot(p.plot);
	}

	// Constructor, Parameterized constructor with no Plot information (uses default
	// Plot where x,y are set to 0, width and depth set to 1)
	public Property(String propertyName, String city, double rentAmount, String owner) {
		this.city = city;
		this.owner = owner;
		this.propertyName = propertyName;
		this.rentAmount = rentAmount;
		this.plot = new Plot();
	}

	// Constructor, Parameterized constructor with 8 parameters
	public Property(String propertyName, String city, double rentAmount, String owner, int x, int y, int width,
			int depth) {
		this.city = city;
		this.owner = owner;
		this.propertyName = propertyName;
		this.rentAmount = rentAmount;
		this.plot = new Plot(x, y, width, depth);
	}

	/**
	 * @return the city
	 */
	public String getCity() {
		return city;
	}

	/**
	 * @param city the city to set
	 */
	public void setCity(String city) {
		this.city = city;
	}

	/**
	 * @return the owner
	 */
	public String getOwner() {
		return owner;
	}

	/**
	 * @param owner the owner to set
	 */
	public void setOwner(String owner) {
		this.owner = owner;
	}

	/**
	 * @return the propertyName
	 */
	public String getPropertyName() {
		return propertyName;
	}

	/**
	 * @param propertyName the propertyName to set
	 */
	public void setPropertyName(String propertyName) {
		this.propertyName = propertyName;
	}

	/**
	 * @return the rentAmount
	 */
	public double getRentAmount() {
		return rentAmount;
	}

	/**
	 * @param rentAmount the rentAmount to set
	 */
	public void setRentAmount(double rentAmount) {
		this.rentAmount = rentAmount;
	}

	/**
	 * @return the plot
	 */
	public Plot getPlot() {
		return plot;
	}

	/*
	 * @param x the x to set
	 * @param y the y to set
	 * @param width the width to set
	 * @param depth the depth to set
	 */
	public Plot setPlot(int x, int y, int width, int depth) {
		this.plot = new Plot(x, y, width, depth);
		return this.plot;
	}

	// Prints out the name, city, owner and rent amount for a property
	@Override
	public String toString() {
		return "Property Name: " + propertyName + "\nLocated in " + city + "\nBelonging to " + owner + "\nRent Amount: "
				+ rentAmount;
	}

}