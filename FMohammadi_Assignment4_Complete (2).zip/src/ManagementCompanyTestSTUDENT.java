


import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;


public class ManagementCompanyTestSTUDENT {
	ManagementCompany mgmt_co;

	@Before
	public void setUp() throws Exception {
		//student create a management company
		mgmt_co = new ManagementCompany("Company P", "423e", 53);

		//student add three properties, with plots, to mgmt co
		Property Prop1 = new Property("First Property", "Rockville", 500, "Michael A", 1, 1, 1, 1);
		Property Prop2 = new Property("Second Property", "Silver Spring", 800, "Sierra T", 5, 5, 3, 3);
		Property Prop3 = new Property("Third Property", "Gaithersburg", 1000, "Daniel A", 9, 9, 1, 1);

		mgmt_co.addProperty(Prop1);
		mgmt_co.addProperty(Prop2);
		mgmt_co.addProperty(Prop3);
	}

	@After
	public void tearDown() {
		//student set mgmt co to null  
		mgmt_co = null;

	}

	@Test
	public void testAddPropertyDefaultPlot() {
		//student should add property with 4 args & default plot (0,0,1,1)
		assertEquals(3, mgmt_co.addProperty("Fourth Property", "Silver Spring", 100, "Christopher A"), .001);

		//student should add property with 8 args
		assertEquals(4, mgmt_co.addProperty("Fifth Property", "Gaithersburg", 300, "Hally K", 8, 8, 1, 1), .001);

		//student should add property that exceeds the size of the mgmt co array and can not be added, add property should return -1
		assertEquals(-1, mgmt_co.addProperty("Unacceptable Property", "Fairfax", 1000, "Mr. None", 3, 3, 1, 1), .001);

	}
 
	@Test
	public void testMaxRentProp() {
		//student should test if maxRentProp contains the maximum rent of properties
		assertEquals(mgmt_co.maxRentProp(), 1000, .001);

	}

	@Test
	public void testTotalRent() {
		//student should test if totalRent returns the total rent of properties
		assertEquals(2300, mgmt_co.totalRent(), .001);

	}

 }
