/**
 * The program demonstrates the SavingsAccount class that extends BankAccount
 * @author Fakhreya Mohammadi - 08/04/2022
 *
 */

// The SavingsAccount starts here 
public class SavingsAccount extends BankAccount {

	// variables are declared and initialized
    private double rate = 0.025;
    private static int savingsNumber = 0;
    private String accountNumber;

    // A constructor that takes a name and an initial balance as parameters and 
    // calls the constructor for the superclass. 
    // initializes accountNumber to be the current value in the superclass accountNumber 
    // (the hidden instance variable) concatenated with a hyphen and then the savingsNumber.
    /**
     * 
     * @param name the name of owner
     * @param initial the initial amount of money
     */
    public SavingsAccount(String name, double initial) {

        super(name, initial);
        accountNumber = super.getAccountNumber() + "-" + savingsNumber;
    }
    
    
    // a copy constructor that creates another savings account for the same person.
    // takes the original savings account and an initial balance as parameters. 
    // calls the copy constructor of the superclass, assign the savingsNumber 
    // to be one more than the savingsNumber of the original savings account. 
    // assigns the accountNumber to be the accountNumber of the superclass concatenated 
    // with the hypen and the savingsNumber of the new account.
    /**
     * 
     * @param original the saving account
     * @param initial the initial balance in account
     */
    public SavingsAccount(SavingsAccount original, double initial) {

        super( original, initial);
        savingsNumber += 1;
        accountNumber = super.getAccountNumber() + "-" + savingsNumber;
    }

    
    // This method will calculate one month's worth of interest 
    // on the balance and deposit it into the account.
    /**
     * The postInterest method calculates the interest
     */
    public void postInterest() {

    	rate = (0.025) / 12;

		setBalance((getBalance() * rate) + getBalance());
    }

    // overrides the getAccountNumber method in the superclass.
    /**
     * The getAccountNumber overrides the super class method called getAccountNumber
     */
    public String getAccountNumber() {

        return accountNumber;
    }
}

