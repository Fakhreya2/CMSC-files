/**
 * The program demonstrates the CheckingAccount class that extends BankAccount
 * @author Fakhreya Mohammadi - 08/04/2022
 *
 */
// The CheckingAccount starts here 
public class CheckingAccount extends BankAccount {

	private static final double FEE = 0.15; // Represents the cost of clearing one check, cents to dollars

	
	/**
	 * The method CheckingAccount initializes the name, current amount and account number
	 * @param name The name of account owner
	 * @param initialAmount the initial amount of money in account
	 */
	public CheckingAccount(String name, double initialAmount) {
		
		// initialize name and current amount
		super(name, initialAmount);
		
		// initialize accountNumber to be the current value in accountNumber concatenated with –10
		setAccountNumber(getAccountNumber() + "-10");
	}

	
	// A new instance method, withdraw, that overrides the withdraw method in the superclass. 
	
	/**
	 * The method withdraw returns a result of true or false based on the withdrawal procedure
	 * @param amount the amount of money to withdraw
	 */
	@Override
	public boolean withdraw(double amount) {
		// calculate amount after fees
		double amountAfterFees = (amount + FEE); // Take the amount to withdraw, add it to the fee for check clearing
		
		// // Call the withdraw method from the superclass
		// return true or false based on result
		return super.withdraw(amountAfterFees); 
		
	}

}