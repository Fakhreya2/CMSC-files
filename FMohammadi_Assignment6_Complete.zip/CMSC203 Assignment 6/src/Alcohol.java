

/*
 * This is the Alcohol class that extends from the Beverage class
 * It will have access to all public members of the Beverage class
 * In addition, it has its own instance fields and methods
 */
public class Alcohol extends Beverage {

	// instance fields are declared and initialized 
	private boolean weekend;
	private final double WEEKEND_PRICE = 0.6;

	/**
	 * This is the class constructor with 3 parameters 
	 * It initializes the name the type and the size by calling the super class
	 * It initializes the weekend using the class field
	 * @param n The name of customer
	 * @param s the size of beverage 
	 * @param w the weekend
	 */
	public Alcohol(String n, SIZE s, boolean w) {
		super(n, TYPE.ALCOHOL, s);
		weekend = w;
	}

	
	/**
	 * This method returns true or false based on weather it is offered in the weekend.   
	 * @return weekend
	 */
	public boolean getWeekend() {
		return weekend;
	}

	
	/**
	 * This method sets the weekend 
	 * @param w weekend
	 */
	public void setWeekend(boolean w) {
		weekend = w;
	}

	
	/**
	 * This method returns the price of weekend.
	 * The additional cost for drinks offered in the weekend is 60 cents
	 * @return WEEKEND_PRICE
	 */
	public double getWeekendPrice() {
		return WEEKEND_PRICE;
	}

	
	/**
	 * An Overridden toString method: String representation 
	 * of an alcohol drink including the name, size, 
	 * whether or not beverage is offered in the weekend and the price.
	 * @return str The string representation 
	 */
	public String toString() {

		String str = "" + getBevName() + ", " + getSize(); // get name and  size of beverage
		double price = 0.0; // set price equal to 0.0
		boolean bool = weekend; // set bool equal to weekend 
		if (bool == true)// if bool is true
			str += ", weekend fee"; // concatenate str with , weekend fee
		price = calcPrice(); // call calcPrice method and assign the returned value to price 
		str += ", price: $" + price; // concatenate str with string price: $ and value price
		return str; // return str
	}

	
	/**
	 * An Overridden equals method: checks equality based on the 
	 * Beverage class equals method and additional instance variables 
	 * of this class which are weekend and bool
	 * @param a
	 * @return bool or false based on the result of if statement condition
	 */
	public boolean equals(Alcohol a) {

		boolean bool = super.equals(a); // call the super class equals method and pass the alcohol a, assign the result to bool
		if (bool == true) { // if bool is true
			if (weekend == a.getWeekend()) // if weekend is same as the weekend of passed alcohol in parameter
				return bool; // return bool which is true
		}
		return false; // otherwise return false
	}

	
	/**
	 * An Overridden calcPrice method
	 * This method gets pricer by calling the super class 
	 * getBasePrice method. It calculates the price of beverage
	 * based on the size of it. 
	 * @return price 
	 */
	public double calcPrice() {
		double price = super.getBasePrice(); // call the getBasePrice of super class

		boolean bool = weekend; // assign weekend to the bool variable

		if (super.getSize() == SIZE.MEDIUM) // if the returned size from the getSize method of super class for beverage is medium 
			price += super.getSizeUp(); // call the getSizeUp method of super class and add the returned value to price
		else if (super.getSize() == SIZE.LARGE) // if the returned size from the getSize method of super class for beverage is large
			price += 2 * super.getSizeUp(); // call the getSizeUp method of super class multiply the returned value by 2 and add the result value to price

		if (bool == true) // if bool is true
			price += WEEKEND_PRICE;  // add the WEEKEND_PRICE price

		return price; // return the price of beverage
	}

}
