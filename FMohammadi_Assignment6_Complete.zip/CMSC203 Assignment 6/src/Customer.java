
// a class to represent a customer
public class Customer {

	// instance fields are declared 
	private String name;
	private int age;

	
	/**
	 * A parameterized constructor that sets the name and age 
	 * @param n name
	 * @param a age
	 */
	public Customer(String n, int a) {
		name = n;
		age = a;
	}

	
	/**
	 * A Copy constructor that creates a new object and copies the name and age
	 * @param c
	 */
	public Customer(Customer c) {
		name = c.getName();
		age = c.getAge();
	}

	
	/**
	 * a default no arg constructor
	 */
	public Customer() {
	}

	
	/**
	 * The getter method for name
	 * @return name
	 */
	public String getName() {
		return name;
	}

	
	/**
	 * The setter method for name
	 * @param n name 
	 */
	public void setName(String n) {
		name = n;
	}

	
	/**
	 * The getter method for age
	 * @return age
	 */
	public int getAge() {
		return age;
	}

	
	/**
	 * The setter method for age 
	 * @param a age 
	 */
	public void setAge(int a) {
		age = a;
	}

	
	/**
	 * An Overridden toString method: String representation for Customer 
	 * including the name and age
	 * @return str
	 */
	public String toString() {
		String str = "Name: " + name + ", Age: " + age;
		return str;
	}
}
