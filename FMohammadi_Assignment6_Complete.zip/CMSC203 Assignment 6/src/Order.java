
import java.util.*;


// This is the class to represent an order. This class implements two interfaces: OrderInterface and Comparable
public class Order implements OrderInterface, Comparable<Order> {

	// Instance variables for order number, order time, 
	// order day and customer,
	// and a list of beverages within this order are declared
	private int orderNumber;
	private int time;
	private DAY day;
	private Customer customer;
	private ArrayList<Beverage> beverageList;

	/**
	 * A parameterized constructor that sets the time, day, and customer
	 * creates an instance of ArrayList named beverageList
	 * @param t time
	 * @param d DAY
	 * @param c customer
	 */
	public Order(int t, DAY d, Customer c) {
		orderNumber = randomNumber();
		time = t;
		day = d;
		customer = c;
		beverageList = new ArrayList<>();
	}

	
	/**
	 * The getter method for orderNumber
	 * @return orderNumber
	 */
	public int getOrderNo() {
		return orderNumber;
	}

	
	/**
	 * The setter method for orderNumber
	 * @param n
	 */
	public void setOrderNo(int n) {
		orderNumber = n;
	}

	
	/**
	 * The getter method for time
	 * @return time
	 */
	public int getOrderTime() {
		return time;
	}

	
	/**
	 * The setter method for time
	 * @param t
	 */
	public void setOrderTime(int t) {
		time = t;
	}

	
	/**
	 * The getter method for day
	 * @return day
	 */
	public DAY getOrderDay() {
		return day;
	}

	
	/**
	 * The setter method for day
	 * @param d
	 */
	public void setOrderDay(DAY d) {
		day = d;
	}

	
	/**
	 * The getter method for customer
	 * @return new Customer(customer)
	 */
	public Customer getCustomer() {
		return new Customer(customer);
	}

	/**
	 * The setter method for customer
	 * @param c
	 */
	public void setCustomer(Customer c) {
		customer = c;
	}

	
	/**
	 * The getter method for beverageList
	 * @return beverageList
	 */
	public ArrayList<Beverage> getBeverages() {
		return beverageList;
	}

	
	/**
	 * A method to generate a random number 
	 * within the range of 10000 and 90000
	 * @return randomNum
	 */
	public int randomNumber() {

		Random random = new Random(); // creates an instance of Random class named random
		int randomNum = 0; // sets randomNum equal to 0
		randomNum = random.nextInt(90000 - 10000); // specifies the range of number and generates a number within the range of 10000 and 90000 
		return randomNum; // returns the randomNum
	}

	
	/**
	 * an Override method that compares this order with another order
	 * based on the order number. Returns 0 if this order number is 
	 * same as another order's order number, 1 if it is greater than 
	 * another order's order number, -1 if it smaller than another 
	 * order's order number
	 */
	@Override
	public int compareTo(Order o) {
		if (orderNumber == o.getOrderNo()) // if this order number is  same as another order's order number
			return 0; // return 0
		else if (orderNumber < o.getOrderNo()) // if it smaller than another  order's order number
			return -1; // return -1
		else
			return 1; // if it is greater than another order's order number, return 1
	}

	
	/**
	 * If the day is weekend it will return true if it is not weekend day it will return false
	 * @return bool
	 */
	@Override
	public boolean isWeekend() {

		boolean bool = false; // set bool equal to false
		if (day == DAY.SATURDAY) // if this day is equal to weekend day SATURDAY
			bool = true; // set bool equal to true
		if (day == DAY.SUNDAY) // if this day is equal to weekend day SUNDAY
			bool = true; // set bool equal to true

		return bool; //return bool
	}

	
	/**
	 * This method returns the number of beverages 
	 * @return beverageList.get(itemNo)
	 */
	@Override
	public Beverage getBeverage(int itemNo) {
		return beverageList.get(itemNo);
	}

	
	
	/**
	 * This method overrides the addNewBeverage method and adds a new beverage of type coffee 
	 * @param bevName
	 * @param size
	 * @param extraShot
	 * @param extraSyrup
	 */
	@Override
	public void addNewBeverage(String bevName, SIZE size, boolean extraShot, boolean extraSyrup) {
		Coffee cofeeOrder = new Coffee(bevName, size, extraShot, extraSyrup); // create new coffee by passing bevName, size, extraShot, extraSyrup to the constructor 
		beverageList.add(cofeeOrder); // add cofeeOrder order to the beverageList 
		}
	
	/**
	 * This method overrides the addNewBeverage method and adds a new beverage of type Alcohol
	 * @param bevName
	 * @param size
	 */
	@Override
	public void addNewBeverage(String bevName, SIZE size) {
		boolean bool = isWeekend(); // call method isWeekend and assign the result to the bool
		Alcohol alcoholOrder = new Alcohol(bevName, size, bool); // create new Alcohol by passing bevName, size, bool to the constructor 
		beverageList.add(alcoholOrder); // add alcoholOrder order to the beverageList
	}
	
	/**
	 * This method overrides the addNewBeverage method and adds a new beverage of type Smoothie
	 * @param bevName
	 * @param size
	 * @param numOfFruits
	 * @param addPRotien
	 */

	@Override
	public void addNewBeverage(String bevName, SIZE size, int numOfFruits, boolean addPRotien) {
		Smoothie smoothieOrder = new Smoothie(bevName, size, numOfFruits, addPRotien); // create new Smoothie by passing bevName, size, numOfFruits, addPRotien to the constructor 
		beverageList.add(smoothieOrder); // add smoothieOrder order to the beverageList
	}

	
	/**
	 * This method overrides the calcOrderTotal and returns the total order price 
	 * @return total
	 */
	@Override
	public double calcOrderTotal() {
		double total = 0; // set total equal to 0
		for (Beverage beverage : beverageList) { // for each beverage in beverage list
			total += beverage.calcPrice(); // call the calcPrice method of beverage class to calculate the price and add it to the total
		}
		return total; // return total
	}

	
	/**
	 * This method analysis the number of beverages and returns the total number of beverages
	 * @param type
	 */
	@Override
	public int findNumOfBeveType(TYPE type) {
		int numOfBeve = 0; // set numOfBeve equal to 0
		for (Beverage beverage : beverageList) { // for each beverage in beverage list
			if (beverage.getType() == type) // if this type equals to the other type
				numOfBeve++; // increment numOfBeve by one
		}
		return numOfBeve; // return numOfBeve
	}

	
	/**
	 * An Overridden toString method: Includes order number, time, day, 
	 * customer name, customer age and the list of beverages 
	 * (with information of the beverage).
	 * @return str
	 */
	@Override
	public String toString() {
		String str = "Order number: " + orderNumber + ", " + time + " ," + day + ", " + customer; // get order number, time, day, and customer
		for (Beverage beverage : beverageList) // for each beverage in beverage list
			str += "\n" + beverage; // concatenate str with beverage each one in new line
		str += ", total: " + calcOrderTotal(); // concatenate String , total: with the returned value from the calcOrderTotal method 
		return str; // return str
	}

	
	/**
	 * This method returns the total of items (beverages) ordered
	 * @return beverageList.size()
	 */
	public int getTotalItems() {
		return beverageList.size();
	}

}
