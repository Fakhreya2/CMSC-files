
// This class is named Smoothie that extends the beverage class
// It has access to all public members of Beverage class
public class Smoothie extends Beverage {

	// The instance fields are declared 
	// The class contains additional instance variables for number of 
	// fruits and boolean variable to indicate if protein powder is added 
	// to the beverage. The cost of adding protein is $1.50 and 
	// each additional fruit costs 50 cents.
	private int fruit;
	private final double FRUIT_PRICE = 0.5;
	private boolean protein;
	private final double PROTEIN_PRICE = 1.5;

	
	/**
	 * A parameterized constructor tha sets the name, size, fruit, and protein
	 * @param n name
	 * @param s size
	 * @param f fruit
	 * @param p protein
	 */ 
	public Smoothie(String n, SIZE s, int f, boolean p) {
		super(n, TYPE.SMOOTHIE, s);
		fruit = f;
		protein = p;
	}

	
	/**
	 * The getter method for fruit
	 * @return fruit
	 */
	public int getNumOfFruits() {
		return fruit;
	}

	
	/**
	 * The setter method for fruit
	 * @param f
	 */
	public void setNumOfFruits(int f) {
		fruit = f;
	}

	
	/**
	 * The getter method for protein
	 * @return protein
	 */
	public boolean getAddProtein() {
		return protein;
	}

	
	/**
	 * The setter method for protein
	 * @param p
	 */
	public void setAddProtein(boolean p) {
		protein = p;
	}

	
	/**
	 * The getter method for FRUIT_PRICE
	 * @return FRUIT_PRICE
	 */
	public double getFruitPrice() {
		return FRUIT_PRICE;
	}

	
	/**
	 * The getter method for PROTEIN_PRICE
	 * @return
	 */
	public double getProteinPrice() {
		return PROTEIN_PRICE;
	}

	
	/**
	 * An Overridden toString method: String representation of
	 * a Smoothie drink including the name , size, whether or not 
	 * protein is added , number of fruits and the price
	 * @return str
	 */
	public String toString() {
		boolean bool = protein; // set bool equal to protein 
		double price = 0.0; // set price equal to 0.0
		String str = "" + getBevName() + ", " + getSize() + ", fruits: " + fruit; // get name, size and fruit
		if (bool == true) { // if bool is true
			str += ", protein"; // concatenate str with protein
		}
		price = calcPrice(); // call calcPrice method and assign the returned value to price 
		str += ", price: $" + price;  // concatenate str with string price: $ and value price
		return str; // return str
	}

	
	/**
	 * An Overridden equals method: checks equality based 
	 * on the Beverage class equals method and additional instance 
	 * variables for this class which are fruit, protein, and bool
	 * @param s
	 * @return bool or false based on the result of if statement condition
	 */
	
	
	public boolean equals(Smoothie s) {
		boolean bool = super.equals(s); // call the super class equals method and pass the smoothie s, assign the result to bool
		if (bool = true) { // if bool is true
			if (fruit == s.getNumOfFruits() && protein == s.getAddProtein()) // if number of fruits are same and the result of addProtien is same as protein 
				return bool; // return bool which is true
		}
		return false; // otherwise return false
	}

	
	/**
	 * An Overridden calcPrice method. This method calculates the cost 
	 * of beverage (Smoothie) based on the size, fruit, and protein. 
	 * @return price
	 */
	@Override
	public double calcPrice() {

		double price = super.getBasePrice(); // call the getBasePrice of super class

		if (super.getSize() == SIZE.MEDIUM) // if the returned size from the getSize method of super class for beverage is medium 
			price += super.getSizeUp(); // call the getSizeUp method of super class and add the returned value to price
		else if (super.getSize() == SIZE.LARGE) // if the returned size from the getSize method of super class for beverage is large
			price += 2 * super.getSizeUp(); // call the getSizeUp method of super class multiply the returned value by 2 and add the result value to price

		double fruitTotal = FRUIT_PRICE * getNumOfFruits(); // Calculate the total price of fruit by multiplying the number of fruits by its price
		price += fruitTotal; // add the fruit'sd cost to price
		boolean bool = protein; // assign protein to the bool variable
		if (bool == true) // if bool is true
			price += PROTEIN_PRICE; // add the WEEKEND_PRICE price

		return price; // return the price of beverage
	}

}
