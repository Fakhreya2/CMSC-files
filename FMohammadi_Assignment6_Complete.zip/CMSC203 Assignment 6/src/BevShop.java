/*
 * Class: CMSC203-46519
 * Instructor: Professor Eivazi
 * Assignment #6
 * Description: This application creates and processes orders of different types of beverages
 * it provides information on all the orders and the total amount on a specific order
 * Additionally, it reports the monthly total number of orders and monthly sale report
 * Due: 08/11/2022
 * Platform/compiler: Eclipse
 * I pledge that I have completed the programming assignment independently.
   I have not copied the code from a student or any source.
   I have not given my code to any student.
   Print your Name here: Fakhreya Mohammadi
*/

import java.util.*;


// The class BevShop starts here which implements the BevShopInterfce interface
public class BevShop implements BevShopInterfce {

	// Variables are declared and initialized
	private int alcOrder;
	private int MIN_AGE_FOR_ALCOHOL = 21;
	private int MAX_ORDER_FOR_ALCOHOL = 3;
	private int MIN_TIME = 8;
	private int MAX_TIME = 23;
	private int MAX_FRUIT = 5;
	private int index;
	private ArrayList<Order> orderList;

	/**
	 * class constructor that creates an instance of ArrayList named orderList
	 */
	public BevShop() {
		orderList = new ArrayList<>();
	}
	
	
	/**
	 * This method returns the number of alcohol drink
	 * @return alcOrder
	 */

	public int getNumOfAlcoholDrink() {
		return alcOrder;
	}
	
	
	/**
	 * This method returns the maximum order for alcohol
	 * @return MAX_ORDER_FOR_ALCOHOL
	 */

	public int getMaxOrderForAlcohol() {
		return MAX_ORDER_FOR_ALCOHOL;
	}
	
	
	/**
	 * This method returns the number of maximum fruits
	 * @return MAX_FRUIT
	 */
	public int getMaxFruits() {
		return MAX_FRUIT;
	}

	
	/**
	 * This method returns the minimum age required for the alcohol use
	 * @return MIN_AGE_FOR_ALCOHOL
	 */
	public int getMinAgeForAlcohol() {
		return MIN_AGE_FOR_ALCOHOL;
	}

	
	/**
	 * This method returns the current order
	 * @return orderList.get(index)
	 */
	public Order getCurrentOrder() {
		return orderList.get(index);
	}

	
	/**
	 * This method sets the number of alcohol drink
	 * @param a
	 */
	public void setNumOfAlcoholDrink(int a) {
		alcOrder = a;
	}

	/**
	 * This method overrides the validTime method, it will return true or false based on the result of if statement condition 
	 * @param time
	 */
	@Override
	public boolean validTime(int time) {
		if (time > MAX_TIME || time < MIN_TIME) // if time is more than maximum time or less than minimum time
			return false; // return false
		else
			return true; // otherwise return true
	}

	
	/**
	 * This method overrides the eligibleForMore method, it will return true or false based on the result of if statement condition
	 */
	@Override
	public boolean eligibleForMore() {
		if (alcOrder < MAX_ORDER_FOR_ALCOHOL) // if order of alcohol is less than MAX_ORDER_FOR_ALCOHOL
			return true; // return true
		else
			return false; // otherwise return false
	}
	
	
	/**
	 * This method overrides the validAge method, it will return true or false based on the result of if statement condition
	 * @param age
	 */
	@Override
	public boolean validAge(int age) {
		if (age > MIN_AGE_FOR_ALCOHOL) { // if age is more than MIN_AGE_FOR_ALCOHOL
			return true; // return true
		}
		return false; // otherwise return false
	}
	
	
	/**
	 * This method overrides the startNewOrder
	 * @param time
	 * @param day
	 * @param customerName
	 * @param customerAge
	 */
	@Override
	public void startNewOrder(int time, DAY day, String customerName, int customerAge) {
		Customer customer = new Customer(customerName, customerAge); // create a new customer instance by passing customerName and 
																		// customerAge to the parameterized constructor
		Order order = new Order(time, day, customer); // create a new order instance by passing time, day and 
														// customer to the parameterized constructor
		orderList.add(order); // add order to order list
		alcOrder = 0; // set alcohol order to 0
		index = orderList.indexOf(order); // assign the index of order to the index variable
	}

	
	/**
	 * This method overrides the processAlcoholOrder
	 * @param bevName
	 * @param size
	 * @param extraShot
	 * @param extraSyrup
	 */
	@Override
	public void processCoffeeOrder(String bevName, SIZE size, boolean extraShot, boolean extraSyrup) {
		orderList.get(index).addNewBeverage(bevName, size, extraShot, extraSyrup); // add new beverage at returned index from orderLIst.get(index) method
	}

	
	/**
	 * This method overrides the processAlcoholOrder
	 * @param bevName
	 * @param size
	 */
	@Override
	public void processAlcoholOrder(String bevName, SIZE size) {
		orderList.get(index).addNewBeverage(bevName, size); // add new beverage at returned index from orderLIst.get(index) method
		alcOrder++; // increment alcOrder by one
	}

	
	/**
	 * This method overrides the processSmoothieOrder
	 * @param bevName
	 * @param size
	 * @param numOfFruits
	 * @param addProtien
	 */
	@Override
	public void processSmoothieOrder(String bevName, SIZE size, int numOfFruits, boolean addProtien) {
		orderList.get(index).addNewBeverage(bevName, size, numOfFruits, addProtien); // add new beverage at returned index from orderLIst.get(index) method
	}

	
	/**
	 * This method returns the order number
	 * @param orderNo
	 */
	@Override
	public int findOrder(int orderNo) {
		int ind = 0; // set ind equal to 0
		while (ind < orderList.size()) { // until ind is less than size of order List
			if (orderList.get(ind).getOrderNo() == orderNo) // if the current index of order number is equal to the passed order number as parameter
				return ind; // return index
			ind++; // increment index by one
		}
		return -1; // otherwise return -1
	}

	
	/**
	 * This method returns the total price of all orders
	 * @param orderNo
	 * @return total
	 */
	@Override
	public double totalOrderPrice(int orderNo) {
		double total = 0.0; // set total equal to zero
		for (Order order : orderList) { // for each order in orderList
			if (order.getOrderNo() == orderNo) { // if the current number of order is equal to the passed order number as parameter
				for (Beverage beverage : order.getBeverages()) { // for each order of beverage in beverage type
					total += beverage.calcPrice(); // call the calcPrice method of beverage and add the returned value to total
				}
			}
		}
		return total; // return the total price
	}

	
	/**
	 * This method calculates the total monthly sale of beverages
	 * @return total
	 */
	@Override
	public double totalMonthlySale() {
		double total = 0; // set total equal to zero
		for (Order order : orderList) { // for each order in orderList
			for (Beverage beverage : order.getBeverages()) { // for each order of beverage in beverage type
				total += beverage.calcPrice(); // call the calcPrice method of beverage and add the returned value to total
			}
		}
		return total; // return the total price
	}

	
	/**
	 * This method sorts the orders based on the index of orders 
	 */
	@Override
	public void sortOrders() {

		for (int i = 0; i < orderList.size() - 1; i++) { // as i equals 0 and as long as i is less than size of orderList
			int minOrderNumIdx = i; // the minimum number of index of order is i
			for (int j = i + 1; j < orderList.size(); j++) { // for j that is 1 plus i and as long as it is less than size of orderList
				if (orderList.get(j).getOrderNo() < orderList.get(minOrderNumIdx).getOrderNo()) { // if order number in index j is less than minimum number of index 
					minOrderNumIdx = j; // set minimum order number index equal to j
				}
			}

			Order temp = orderList.get(minOrderNumIdx); // assign the minimum order index to the temp
			orderList.set(minOrderNumIdx, orderList.get(i)); // set the minimum order index and i index
			orderList.set(i, temp); // set i and the tem by calling the set method of orderList
		}
	}

	
	/**
	 * This method returns the order at specified index
	 * @param index
	 * @return orderList.get(index)
	 */
	@Override
	public Order getOrderAtIndex(int index) {
		return orderList.get(index);
	}

	
	/**
	 * This method examines that the fruit is maximum or not
	 * @param fruit
	 * @return true or false based on the result of if statement condition
	 */
	public boolean isMaxFruit(int fruit) {
		if (fruit > MAX_FRUIT) { // if fruit is more than MAX_FRUIT
			return true; // return true 
		} else
			return false; // otherwise return false
	}

	
	/**
	 * This method returns the total number of monthly orders 
	 * @return orderList.size()
	 */
	public int totalNumOfMonthlyOrders() {
		return orderList.size();
	}

	
	/**
	 * An Overridden toString method which is the string representation of all the orders 
	 * and the total monthly sale.  
	 */
	public String toString() {
		String s = "Monthly Orders\n";

		for (Order o : orderList) { // for each order o in order list
			s += o.toString(); // add s and the string representation of order o to the s
		}
		s += "Total Sale: " + totalMonthlySale(); // call the totalMonthlySale to get the total monthly sold

		return s; // return s
	}

}
