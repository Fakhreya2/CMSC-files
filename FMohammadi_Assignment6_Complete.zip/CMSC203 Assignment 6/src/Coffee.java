

// This is the Coffee class that extends the beverage class
// It has access to all public members of the Beverage class and
// has its own additional instance variables of type boolean to 
// indicate if it contains extra shot of coffee (additional cost of 50 cents) 
// and extra syrup (additional cost of 50 cents).
public class Coffee extends Beverage {

	// instance fields are declared and initialized
	private boolean extraShot;
	private final double SHOT_PRICE = 0.5;
	private boolean extraSyrup;
	private final double SYRUP_PRICE = 0.5;

	/**
	 * A parameterized constructor that sets the name, type, size
	 * extra Shot, and SYRUP PRICE fields
	 * @param n name
	 * @param s size
	 * @param sh extra Shot
	 * @param sy SYRUP PRICE
	 */
	public Coffee(String n, SIZE s, boolean sh, boolean sy) {
		super(n, TYPE.COFFEE, s);
		extraShot = sh;
		extraSyrup = sy;
	}

	
	/**
	 * The getter method for extraShot
	 * @return extraShot
	 */
	public boolean getExtraShot() {
		return extraShot;
	}

	
	/**
	 * The setter method for extraShot
	 * @param s size
	 */
	public void setExtraShot(boolean s) {
		extraShot = s;
	}

	
	/**
	 * The getter method for extraSyrup
	 * @return extraSyrup
	 */
	public boolean getExtraSyrup() {
		return extraSyrup;
	}

	
	/**
	 * Th setter method for extraSyrup
	 * @param s extraSyrup
	 */
	public void setExtraSyrup(boolean s) {
		extraSyrup = s;
	}

	
	/**
	 * The getter method for ShotPrice
	 * @return SHOT_PRICE
	 */
	public double getShotPrice() {
		return SHOT_PRICE;
	}

	
	/**
	 * The getter method for SyrupPrice
	 * @return SYRUP_PRICE
	 */
	public double getSyrupPrice() {
		return SYRUP_PRICE;
	}

	
	/**
	 * An Overridden  toString method: String representation of Coffee 
	 * beverage, including the name , size ,  whether it contains 
	 * extra shot, extra syrup and the price of the coffee
	 * @return str
	 */
	public String toString() {

		boolean bool = extraShot; // set bool equal to extraShot 
		double price = 0.0;
		String str = "" + getBevName() + ", " + getSize(); // get name and size of beverage
		if (bool == true) { // bool is true
			str += ", " + "extra shot";
			bool = extraSyrup; // set bool equal to extraSyrup 
			if (bool == true) { // if bool is true
				str += ", " + "extra syrup"; // concatenate str with string  ,  and extra syrup
				price = calcPrice(); // call calcPrice method and assign the returned value to price 
				str += ", price: $" + price; // concatenate str with string price: $ and value price
				return str; // return price
			}
		}
		bool = extraSyrup; // set bool equal to extraSyrup
		if (bool == true) { // if bool is true
			str += ", " + "extra shot"; // concatenate str with string  ,  and extra shot
		}
		price = calcPrice(); // call calcPrice method and assign the returned value to price 
		str += ", price: $" + price; // concatenate str with string price: $ and value price
		return str; // return str
	}

	
	/**
	 * An Overridden calcPrice method which calculates the cost of
	 * beverage (coffee) based on the size extraShot and extraSyrup
	 * @return price
	 */
	public double calcPrice() {

		double price = super.getBasePrice(); // call the getBasePrice of super class
		boolean boolShot = extraShot; // assign extraShot to the boolShot
		boolean boolSyrup = extraSyrup; // assign extraShot to the boolSyrup

		if (super.getSize() == SIZE.MEDIUM) // if the returned size from the getSize method of super class for beverage is medium 
			price += super.getSizeUp(); // call the getSizeUp method of super class and add the returned value to price
		else if (super.getSize() == SIZE.LARGE) // if the returned size from the getSize method of super class for beverage is large
			price += 2 * super.getSizeUp(); // call the getSizeUp method of super class multiply the returned value by 2 and add the result value to price

		if (boolShot == true) // if boolShot is true
			price += SHOT_PRICE; // add the SHOT_PRICE price
		if (boolSyrup == true) // if boolSyrup is true
			price += SYRUP_PRICE; // add the SYRUP_PRICE price

		return price; // return the price
	}

	
	/**
	 * An Overridden  equals method: checks equality based on 
	 * the Beverage class equals method and additional instance 
	 * variables for this class which includes extraShot extraSyrup and bool
	 * @param c coffee
	 * @return bool or false based on the result of if statement condition
	 */
	public boolean equals(Coffee c) {
		boolean bool = super.equals(c); // call the super class equals method and pass the coffee c, assign the result to bool
		if (bool = true) { // if bool is true
			if (extraShot == c.getExtraShot() && extraSyrup == c.getExtraSyrup()) // if the result of extraShot are same and the result of extraSyrup is same 
				return bool; // return bool which is true
		}
		return false; // otherwise return false
	}

}
