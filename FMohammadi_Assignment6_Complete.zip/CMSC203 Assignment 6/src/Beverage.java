

// An abstract class called Beverage
public abstract class Beverage {

	// instance fields are declared and initialized
	// Instance variables for beverage name, beverage type, size, 
	// and constant attributes for the base price ($2.0) 
	// and size price (additional $1 to go a size up).
	private String name;
	private TYPE type;
	private SIZE size;
	private final double PRICE = 2.0;
	private final double SIZE_UP = 1.0;

	
	/**
	 * This is a •	A parameterized constructor to create a 
	 * Beverage object given its name, type and  size
	 * @param n name
	 * @param coffee type
	 * @param s size
	 */
	public Beverage(String n, TYPE coffee, SIZE s) {
		name = n;
		type = coffee;
		size = s;
	}

	
	/*
	 * An abstract methods called calcPrice that calculates and returns the beverage price. 
	 */
	public abstract double calcPrice();

	
	/**
	 * The getter method for name
	 * @return name
	 */
	public String getBevName() {
		return name;
	}

	
	/**
	 * The setter method for name
	 * @param n name
	 */
	public void setName(String n) {
		name = n;
	}

	
	/**
	 * The getter method for type
	 * @return type
	 */
	public TYPE getType() {
		return type;
	}

	
	/**
	 * The setter method for type
	 * @param t type
	 */
	public void setType(TYPE t) {
		type = t;
	}

	
	/**
	 * The getter method for size
	 * @return size
	 */
	public SIZE getSize() {
		return size;
	}

	
	/**
	 * The setter method for size
	 * @param s size
	 */
	public void setSize(SIZE s) {
		size = s;
	}

	
	/**
	 * The getter method for BasePrice
	 * @return PRICE
	 */
	public double getBasePrice() {
		return PRICE;
	}

	
	/**
	 * The getter method for SizeUp
	 * @return SIZE_UP
	 */
	public double getSizeUp() {
		return SIZE_UP;
	}

	
	/**
	 * An Overridden toString method: String representation 
	 * for Beverage including the name and size
	 * @return name + ", " + size
	 */
	@Override
	public String toString() {
		return name + ", " + size;
	}

	
	/**
	 * An Overridden equals method: checks equality 
	 * based on name, type, size of the beverage
	 * @param beverage
	 * @return true or false based on the result of if statement condition
	 */
	public boolean equals(Beverage beverage) {
		if (name.equals(beverage.getBevName())) { // if names of beverages are equal
			if (size == beverage.getSize() && type == beverage.getType()) // if sizes and types of beverages are equal
				return true; // return true
		}
		return false; // otherwise return false
	}

}
