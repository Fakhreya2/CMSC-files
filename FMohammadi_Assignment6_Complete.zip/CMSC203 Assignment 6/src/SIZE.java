// An enumerated type called SIZE.  The valid values are SMALL, MEDIUM, and LARGE
public enum SIZE {
	SMALL, MEDIUM, LARGE;
}
