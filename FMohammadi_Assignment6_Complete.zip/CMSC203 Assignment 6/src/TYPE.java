
// An enumerated type called TYPE.  The valid values are COFFEE, SMOOTHIE, and ALCOHOL.
public enum TYPE {
	COFFEE, SMOOTHIE, ALCOHOL;
}

