/*
 * Class: CMSC203-46519
 * Instructor: Professor Eivazi
 * Assignment #5
 * Description: This application will manipulates a two-dimensional ragged array of doubles. 
 * This utility class will be used to create a Sales Report for Retail District #5. 
 * It will accommodate positive and negative numbers. The application will read the data from the files
 * and will determine the highest, lowest and other numbers from the files. It will then calculate the average
 * total, highest and lowest elements in array.  
 * Due: 07/28/2022
 * Platform/compiler: Eclipse
 * I pledge that I have completed the programming assignment independently.
   I have not copied the code from a student or any source.
   I have not given my code to any student.
   Print your Name here: Fakhreya Mohammadi
*/

import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.Scanner;



public final class TwoDimRaggedArrayUtility {
	
	
	
	public TwoDimRaggedArrayUtility() {
		
	}

  /**
   * Returns the average of the elements in the two dimensional array
   * 
   * @param data the two dimensional array getting the average of
   * @return the average of the elements in the two dimensional array (total of elements/num of
   *         elements)
   */
  public static double getAverage(double[][] data) {
    
    int members = 0;
    double total = 0;
    for (int k = 0;k < data.length;k++) {
    	members += data[k].length; 
      for (int i = 0;i < data[k].length;i++) {
    	  total += data[k][i];
      }
    }
    
    return total / members;
  }

  /**
   * Returns the total of the selected column in the two dimensional array index 0 refers to the
   * first column. If a row in the two dimensional array doesn't have this column index, it is not
   * an error, it doesn't participate in this method.
   * 
   * @param data the two dimensional array
   * @param col the column index to take the total of (0 refers to the first column)
   * @return the total of the column
   */
  public static double getColumnTotal(double[][] data, int col) {
    double colSum = 0;
    for (int m = 0;m < data.length;m++) {
      if (col >= data[m].length) {
        continue;
      }
      colSum += data[m][col];
    }
    return colSum;
  }

  /**
   * Returns the largest element in the two dimensional array
   * 
   * @param data the two dimensional array
   * @return the largest element in the two dimensional array
   */
  public static double getHighestInArray(double[][] data) {
    double highest = -999999;
    for (int n = 0;n < data.length;n++) { 
      for (int h = 0;h < data[n].length;h++) {
        if (data[n][h] > highest) {
        	highest = data[n][h];
        }
      }
    }
    return highest;
  }

  /**
   * Returns the largest element of the selected column in the two dimensional array index 0 refers
   * to the first column. If a row in the two dimensional array doesn't have this column index, it
   * is not an error, it doesn't participate in this method.
   * 
   * @param data the two dimensional array
   * @param col the column index to find the largest element of (0 refers to the first column)
   * @return the largest element of the column
   */
  public static double getHighestInColumn(double[][] data, int col) {
    double highest = -999999;
    for (int v = 0;v < data.length; v++) {
      if (col >= data[v].length) {
        continue;
      }
      if (data[v][col] > highest) {
    	  highest = data[v][col];
      }
    }
    return highest;
  }

  /**
   * Returns index of the largest element of the selected column in the two dimensional array index
   * 0 refers to the first column. If a row in the two dimensional array doesn't have this column
   * index, it is not an error, it doesn't participate in this method.
   * 
   * @param data the two dimensional array
   * @param col the column index to find the largest element of (0 refers to the first column)
   * @return the index of the largest element of the column
   */
  public static int getHighestInColumnIndex(double[][] data, int col) {
    double highest = -999999;
    int index = -1;
    for (int b = 0;b < data.length;b++) {
      if (col >= data[b].length) {
        continue;
      }
      if (data[b][col] > highest ) {
    	  highest = data[b][col];
        index = b;
      }
    }
    return index;
  }

  /**
   * Returns the largest element of the selected row in the two dimensional array index 0 refers to
   * the first row.
   * 
   * @param data the two dimensional array
   * @param row the row index to find the largest element of (0 refers to the first row)
   * @return the largest element of the row
   */
  public static double getHighestInRow(double[][] data, int row) {
    double highest = -999999;
    for (int p = 0;p < data[row].length; p++) {
      if (data[row][p] > highest) {
    	  highest = data[row][p];
      }
    }
    return highest;
  }

  /**
   * Returns the largest element of the selected row in the two dimensional array index 0 refers to
   * the first row.
   * 
   * @param data the two dimensional array
   * @param row the row index to find the largest element of (0 refers to the first row)
   * @return the largest element of the row
   */
  public static int getHighestInRowIndex(double[][] data, int row) {
    double highest = -999999;
    int index = -1;
    for (int f = 0;f < data[row].length;f++) {
      if (data[row][f] > highest) {
    	  highest = data[row][f];
        index = f;
      }
    }
    return index;
  }

  /**
   * Returns the smallest element in the two dimensional array
   * 
   * @param data the two dimensional array
   * @return the smallest element in the two dimensional array
   */
  public static double getLowestInArray(double[][] data) {
    double lowest = 999999;
    for (int g = 0;g < data.length; g++) { 
      for (int j = 0;j < data[g].length;j++) {
        if (data[g][j] < lowest) {
        	lowest = data[g][j];
        }
      }
    }
    return lowest;
  }

  /**
   * Returns the smallest element of the selected column in the two dimensional array index 0 refers
   * to the first column. If a row in the two dimensional array doesn't have this column index, it
   * is not an error, it doesn't participate in this method.
   * 
   * @param data the two dimensional array
   * @param col the column index to find the smallest element of (0 refers to the first column)
   * @return the smallest element of the column
   */
  public static double getLowestInColumn(double[][] data, int col) {
    double lowest = 999999;
    for (int i = 0;i < data.length;i++) {
      if (col >= data[i].length) {
        continue;
      }
      if (data[i][col] < lowest) {
    	  lowest = data[i][col];
      }
    }
    return lowest;
  }

  /**
   * Returns the index of the smallest element of the selected column in the two dimensional array
   * index 0 refers to the first column. If a row in the two dimensional array doesn't have this
   * column index, it is not an error, it doesn't participate in this method.
   * 
   * @param data the two dimensional array
   * @param col the column index to find the smallest element of (0 refers to the first column)
   * @return the index of the smallest element of the column
   */
  public static int getLowestInColumnIndex(double[][] data, int col) {
    double lowest = 999999;
    int index = -1;
    for (int m = 0;m < data.length;m++) {
      if (col >= data[m].length) {
        continue;
      }
      if (data[m][col] < lowest ) {
    	  lowest = data[m][col];
        index = m;
      }
    }
    return index;
  }

  /**
   * Returns the smallest element of the selected row in the two dimensional array index 0 refers to
   * the first row.
   * 
   * @param data the two dimensional array
   * @param row the row index to find the smallest element of (0 refers to the first row)
   * @return the smallest element of the row
   */
  public static double getLowestInRow(double[][] data, int row) {
    double lowest = 999999;
    for (int y = 0; y < data[row].length; y++) {
      if (data[row][y] < lowest) {
    	  lowest = data[row][y];
      }
    }
    return lowest;
  }

  /**
   * Returns the index of the smallest element of the selected row in the two dimensional array
   * index 0 refers to the first row.
   * 
   * @param data the two dimensional array
   * @param row the row index to find the smallest element of (0 refers to the first row)
   * @return the index of the smallest element of the row
   */
  public static int getLowestInRowIndex(double[][] data, int row) {
    double lowest = 999999;
    int index = -1;
    for (int k = 0; k < data[row].length; k++) {
      if (data[row][k] < lowest) {
    	  lowest = data[row][k];
        index = k;
      }
    }
    return index;
  }

  /**
   * Returns the total of the selected row in the two dimensional array index 0 refers to the first
   * row.
   * 
   * @param data the two dimensional array
   * @param row the row index to take the total of (0 refers to the first row)
   * @return the total of the row
   */
  public static double getRowTotal(double[][] data, int row) {
    double total = 0;
    for (int n = 0; n < data[row].length; n++) {
    	total += data[row][n];
    }
    return total;
  }

  /**
   * Returns the total of all the elements of the two dimensional array
   * 
   * @param data the two dimensional array getting total of
   * @return the sum of all the elements in the two dimensional array
   */
  public static double getTotal(double[][] data) {
    double total = 0;
    for (int p = 0; p < data.length; p++) { 
      for (int j = 0; j < data[p].length;j++) {
    	  total += data[p][j];
      }
    }
    
    return total;
  }

  /**
   * Reads from a file and returns a ragged array of doubles The maximum rows is 10 and the maximum
   * columns for each row is 10 Each row in the file is separated by a new line Each element in the
   * row is separated by a space Suggestion: You need to know how many rows and how many columns
   * there are for each row to create a ragged array. 1. Read the doubles from the file into an a
   * temporary array [10][10] of Strings which was initialized to nulls. 2. Find out how many rows
   * there are (any row that has the first element != null is a valid row) 3. Create the array based
   * on the num of rows, i.e. double[][]array = new double[#rows][] 4. Determine the number of
   * columns for the first row (any element != null is a valid element) 5. Create the first row,
   * i.e. array[0] = new double[#columns] 6. Put the values from the temporary array into in the row
   * (don't forget to convert from strings to doubles) 7. Repeat for all rows
   * 
   * @param file the file to read from
   * @return a two dimensional ragged (depending on data) array of doubles if the file is not empty,
   *         returns a null if file is empty
   * @throws FileNotFoundException 
   */
  public static double[][] readFile(File file) throws FileNotFoundException  {
    Scanner sc = new Scanner(file);
    int indexRow = 0; 
    String[][] temp = new String[10][]; 
    
    // read file and pass numbers to temp array as Strings
    while (sc.hasNextLine()) {
     String[] row = sc.nextLine().split(" ");
     temp[indexRow] = new String[row.length];
     for (int i = 0;i < row.length;i++) {
       temp[indexRow][i]=row[i];   
     }
     indexRow++;
    }
   // Create double data array and parse numbers as doubles
    double[][]data = new double[indexRow][];
    for (int i = 0; i < indexRow;i++) {
      data[i]= new double[temp[i].length];
      for (int j = 0;j < temp[i].length;j++) {
          System.out.print(temp[i][j] + " ");
          data[i][j] = Double.parseDouble(temp[i][j]);
      }
      System.out.println();
    }
    
    sc.close();
    return data;
  }

  /**
   * Writes the ragged array of doubles into the file. Each row is on a separate line within the
   * file and each double is separated by a space.
   * 
   * @param data two dimensional ragged array of doubles
   * @param outputFile the file to write to
   * @throws FileNotFoundException 
   */
  public static void writeToFile(double[][] data, File outputFile) throws FileNotFoundException {
    PrintWriter output = new PrintWriter(outputFile);
    StringBuilder sb = new StringBuilder();
    for (int i = 0;i < data.length;i++) {
      for (int j = 0;j < data[i].length;j++) {
        sb.append(data[i][j]+ " ");
      }
      sb.append("\n");
    }
    output.print(sb.toString());
    output.close();
  }

}