import static org.junit.Assert.*;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class HolidayBonusTestSTUDENT {
  // create several (more than 2) data sets for testing. These data sets must be different
  // then the data sets in HolidayBonusTest
  private double[][] dataSet1 = {{1.0, 2.0, 3.0, 4.0}, {10.0, 65.0, 32.9, 43.0}, {43.98, 435.08}};
  private double[][] dataSet2 = {{12.0, 23.0, 23.9, 44.34, 34.4}, {34.0}, {-1.0, 33.0, 34.34, -42.0}, {132.0, 343.0}};
  private double[][] dataSet3 = {{-3.34, 34.34, 123.04, 43.34, 434.0}, {123.4, -3,0}, {34.45, 54.6, -43.0, 45.56},
      {345.45, 656.6, 56.5, -233.5}};

  @Before
  public void setUp() throws Exception {}

  @After
  public void tearDown() throws Exception {}


  /**
   * Test calculateHolidayBonus method with a high of 5000, low of 1000 and 2000 as other
   */

  @Test
  public void testCalculateHolidayBonusSTUDENTA() {
    // test for each of the data sets
    try {
      double[] result = HolidayBonus.calculateHolidayBonus(dataSet1, 5000, 1000, 2000);
      assertEquals(4000.0, result[0], .001);
      assertEquals(14000.0, result[1], .001);
      assertEquals(10000.0, result[2], .001);

      result = HolidayBonus.calculateHolidayBonus(dataSet2, 5000, 1000, 2000);
      assertEquals(14000.0, result[0], .001);
      assertEquals(2000.0, result[1], .001);
      assertEquals(7000.0, result[2], .001);

      result = HolidayBonus.calculateHolidayBonus(dataSet3, 5000, 1000, 2000);
      assertEquals(14000.0, result[0], .001);
      assertEquals(2000.0, result[1], .001);
      assertEquals(9000.0, result[2], .001);
    } catch (Exception e) {
      fail("This should not have caused an Exception");
    }
  }


  /**
   * Test calculateHolidayBonus method with a high of 1000, low of 250 and 500 as other
   */

  @Test
  public void testCalculateHolidayBonusSTUDENTB() {
    // test for each of the data sets
    try {
      double[] result = HolidayBonus.calculateHolidayBonus(dataSet1, 1000, 250, 500);
      assertEquals(1000.0, result[0], .001);
      assertEquals(3000.0, result[1], .001);
      assertEquals(2000.0, result[2], .001);

      result = HolidayBonus.calculateHolidayBonus(dataSet2, 1000, 250, 500);
      assertEquals(3000.0, result[0], .001);
      assertEquals(500.0, result[1], .001);
      assertEquals(1500.0, result[2], .001);

      result = HolidayBonus.calculateHolidayBonus(dataSet3, 1000, 250, 500);
      assertEquals(3000.0, result[0], .001);
      assertEquals(500.0, result[1], .001);
      assertEquals(2000.0, result[2], .001);
    } catch (Exception e) {
      fail("This should not have caused an Exception");
    }

  }

  /**
   * Test calculateTotalHolidayBonus method with a high of 5000, low of 1000 and 2000 as other
   */
  @Test
  public void testCalculateTotalHolidayBonusA() {
    // test for each of the data sets
    assertEquals(28000.0, HolidayBonus.calculateTotalHolidayBonus(dataSet1, 5000, 1000, 2000),.001);
    assertEquals(33000.0, HolidayBonus.calculateTotalHolidayBonus(dataSet2, 5000, 1000, 2000),.001);
    assertEquals(37000.0, HolidayBonus.calculateTotalHolidayBonus(dataSet3, 5000, 1000, 2000),.001);
  }

  /**
   * Test calculateTotalHolidayBonus method with a high of 1000, low of 250 and 500 as other
   */
  @Test
  public void testCalculateTotalHolidayBonusB() {
    // test for each of the data sets
    assertEquals(6000.0, HolidayBonus.calculateTotalHolidayBonus(dataSet1, 1000, 250, 500), .001);
    assertEquals(7000.0, HolidayBonus.calculateTotalHolidayBonus(dataSet2, 1000, 250, 500), .001);
    assertEquals(8000.0, HolidayBonus.calculateTotalHolidayBonus(dataSet3, 1000, 250, 500), .001);
  }

}