

import static org.junit.Assert.*;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.Scanner;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class TwoDimRaggedArrayUtilitySTUDENT_Test {
	//STUDENT fill in dataSetSTUDENT with values, it must be a ragged array
	private double[][] dataSet1 = {{10.0, 20.0, 30.0, 40.0}, {50.0, 60.0, 40.0, 70.0}, {100.0, 90.0}};
	private double[][] dataSet2 = {{-10.0, 30.0, 40.0, -50.0}, {90}, {50.0}, {20.5, 70.5, 30.0, 40.5}};
	private double[][] dataSet3 = {{100.0, 20.0, 45.5, 30.0, 90.0}, {-9, -5}, {-4, 7.0, 3.0, 2.5, 4.0}, {1.0, 50.0, 40.0}};
	
	private File inputFile,outputFile;

	@Before
	public void setUp() throws Exception {
		outputFile = new File("TestOut.txt");
	}

	@After
	public void tearDown() throws Exception {
		 dataSet1 = dataSet2 = dataSet3 = null;
		 inputFile = outputFile = null;
	}

	/**
	 * Student Test getTotal method
	 * Return the total of all the elements in the two dimensional array
	 */
	@Test
	public void testGetTotal() {
		assertEquals(510.0,TwoDimRaggedArrayUtility.getTotal(dataSet1),.001);
	    assertEquals(311.5,TwoDimRaggedArrayUtility.getTotal(dataSet2),.001);
	    assertEquals(375.0,TwoDimRaggedArrayUtility.getTotal(dataSet3),.001);	
	}

	/**
	 * Student Test getAverage method
	 * Return the average of all the elements in the two dimensional array
	 */
	@Test
	public void testGetAverage() {
		assertEquals(51.0,TwoDimRaggedArrayUtility.getAverage(dataSet1),.001);
	    assertEquals(31.15,TwoDimRaggedArrayUtility.getAverage(dataSet2),.001);
	    assertEquals(25.0,TwoDimRaggedArrayUtility.getAverage(dataSet3),.001);
	}

	/**
	 * Student Test getRowTotal method
	 * Return the total of all the elements of the row.
	 * Row 0 refers to the first row in the two dimensional array
	 */
	@Test
	public void testGetRowTotal() {
		assertEquals(220.0,TwoDimRaggedArrayUtility.getRowTotal(dataSet1,1),.001);
	    assertEquals(10.0,TwoDimRaggedArrayUtility.getRowTotal(dataSet2,0),.001);
	    assertEquals(12.5,TwoDimRaggedArrayUtility.getRowTotal(dataSet3,2),.001);
	}


	/**
	 * Student Test getColumnTotal method
	 * Return the total of all the elements in the column. If a row in the two dimensional array
	 * doesn't have this column index, it is not an error, it doesn't participate in this method.
	 * Column 0 refers to the first column in the two dimensional array
	 */
	@Test
	public void testGetColumnTotal() {
		 assertEquals(160.0,TwoDimRaggedArrayUtility.getColumnTotal(dataSet1,0),.001);
		    assertEquals(150.5,TwoDimRaggedArrayUtility.getColumnTotal(dataSet2,0),.001);
		    assertEquals(72.0,TwoDimRaggedArrayUtility.getColumnTotal(dataSet3,1),.001);
	}


	/**
	 * Student Test getHighestInArray method
	 * Return the largest of all the elements in the two dimensional array.
	 */
	@Test
	public void testGetHighestInArray() {
		assertEquals(100.0, TwoDimRaggedArrayUtility.getHighestInArray(dataSet1), .001);
		assertEquals(90.0, TwoDimRaggedArrayUtility.getHighestInArray(dataSet2), .001);
		assertEquals(100.0, TwoDimRaggedArrayUtility.getHighestInArray(dataSet3), .001);
	
	}
	

	/**
	 * Test the writeToFile method
	 * write the array to the outputFile File
	 * then read it back to make sure formatted correctly to read 
	 * 
	 */
	@Test
	public void testWriteToFile() throws FileNotFoundException {
		double[][] array=null;
		outputFile = new File("dataSet1.txt");
		TwoDimRaggedArrayUtility.writeToFile(dataSet1, outputFile);
		
		outputFile = new File("dataSet2.txt");
		TwoDimRaggedArrayUtility.writeToFile(dataSet2, outputFile);
		
		outputFile = new File("dataSet3.txt");
		TwoDimRaggedArrayUtility.writeToFile(dataSet3, outputFile);
		
		inputFile = new File("dataSet1.txt");
		array = TwoDimRaggedArrayUtility.readFile(inputFile);
		assertArrayEquals(dataSet1, array);
		
		inputFile = new File("dataSet2.txt");
		array = TwoDimRaggedArrayUtility.readFile(inputFile);
		assertArrayEquals(dataSet2, array);
		
		inputFile = new File("dataSet3.txt");
		array = TwoDimRaggedArrayUtility.readFile(inputFile);
		assertArrayEquals(dataSet3, array);	
	}

}
