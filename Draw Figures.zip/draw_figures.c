#include <stdio.h>
#include <stdlib.h>
static int check_number(int number);
int draw_rectangle(char first_char, char second_char, int width, int length);
int draw_triangle(char first_char, char second_char, int size, unsigned int seed);
static void get_input(int* result, int* shape);


static void get_input(int* result, int* shape) {
  printf("Enter 1(rectangle), 2(triangle), 0(quit): ");
  scanf("%d", shape);
  *result = check_number(*shape);
}



static int check_number(int number) {

  if (number == 0 || number == 1 || number == 2) {
      return 0;
  } else {
    return 1;
  }
}



int draw_rectangle(char first_char, char second_char, int width, int length) {
  int i, j, state = 0;
  if (width < 1 || length < 1) {
    printf("Invalid values provided.\n");
    return 0;
  } else {
    printf("Rectangle\n");
    for (i = 0; i < width; i++) {
      if (state % 2 == 0) {
	for (j = 0; j < length; j++) {
	  printf("%c", first_char);
	}
      } else {
	for (j = 0; j < length; j++) {
	  printf("%c", second_char);
	}
      }
      printf("\n");
      state++;
    }
    return 1;
  }

}

int draw_triangle(char first_char, char second_char, int size, unsigned int seed) {

  
  int j, i,m, n, random_value, state = size - 1, top = 1;
  
  
  
    if (size < 1) {
      printf("Invalid values provided.\n");
      return 0;
    } else {
       srand(seed);
      printf("Triangle\n");
      for (i = 0; i < size; i++) {
	for(j = 0; j < state; j++) {
	  printf("_");
	}

	
	for (m = 0; m < top; m++) {
	   random_value = rand();
	  
	  if (random_value % 2 == 0) {
	    printf("%c", first_char);
	  } else {
	    printf("%c", second_char);
	  }
	}
	top += 2;
	
	for (n = 0; n < state; n++) {
	  printf("_");
	}
	printf("\n");
	state--;
      }
      
      return 1;
    }
}




int main() {
  int shape = 1;
  int result;
  int width;
  int length;
  int size;
  unsigned int seed;
  char first_char;
  char second_char;
  int *p = &shape;
  int *q = &result;

  get_input(q, p);

  while (shape != 0) {
    
    if (result == 0) {
      if (shape == 1) {
	printf("Enter two characters (separated by space), width and length: ");
	scanf(" %c %c %d %d", &first_char, &second_char, &width, &length);
        draw_rectangle(first_char, second_char, width, length);
	get_input(q, p);
      } else if (shape == 2) {
	printf("Enter two characters (separated by space), size and seed: ");
	scanf(" %c %c %d %u", &first_char, &second_char, &size, &seed);
        draw_triangle(first_char, second_char, size, seed);

	get_input(q, p);
      } else {
	printf("Bye Bye.");
	return 0;
      }
    } else {
      printf("Invalid choice.\n");
      get_input(q, p);
    }
  }
  printf("Bye Bye.\n");
  return 0;
}

