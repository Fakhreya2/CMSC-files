#include <stdio.h>
#include <stdlib.h>             /* Needed for pseudo-random numbers */

int main(void) {
   unsigned int seed = 10;
   int i, times = 20;

   srand(seed);                 /* Setting seed for random number generation */
   for (i = 1; i <= times; i++) {
      /* rand() returns pseudo-random value between 0 and RAND_MAX */
      int random_int_value = rand();
      printf("%d\n", random_int_value);
   }

   return 0;
}
